// SPDX-License-Identifier: Apache-2.0
package ca.kolsteren.voicebutton;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.ImageView;
import java.util.Collections;
import java.util.Map;
import me.jxl.kiosk.plugins.KioskPlugin;
import me.jxl.kiosk.plugins.KsTheme;
import me.jxl.kiosk.plugins.OverlayFactory;
import me.jxl.kiosk.plugins.OverlaySpec;
import me.jxl.kiosk.plugins.PluginHost;

/**
 * Draws a round microphone button above the screensaver. A tap fires the "micTap" gesture trigger, which the user maps
 * to Start a voice command under Settings > Gestures > Plugin trigger. The plugin itself never touches the microphone.
 */
public final class VoiceButtonPlugin implements KioskPlugin {
    static final String OVERLAY = "mic";
    static final String TRIGGER = "micTap";
    static final String DEFAULT_ICON = "mdi:microphone";

    /** Everything the button looks like, so an unchanged configuration never rebuilds the view. */
    static final class Look {
        final String corner, icon;
        final int size, margin, iconColor, buttonColor, opacity;
        final boolean outline;

        Look(Map<String, Object> s) {
            corner = text(s, "corner", "Bottom right");
            icon = text(s, "icon", DEFAULT_ICON).isEmpty() ? DEFAULT_ICON : text(s, "icon", DEFAULT_ICON);
            size = number(s, "size", 72);
            margin = number(s, "margin", 20);
            iconColor = color(s, "iconColor", Color.WHITE);
            buttonColor = color(s, "buttonColor", Color.BLACK);
            opacity = Math.max(0, Math.min(100, number(s, "opacity", 45)));
            outline = flag(s, "outline", true);
        }

        String anchor() {
            switch (corner) {
                case "Bottom left": return OverlaySpec.BOTTOM_LEFT;
                case "Top right": return OverlaySpec.TOP_RIGHT;
                case "Top left": return OverlaySpec.TOP_LEFT;
                case "Bottom centre": return OverlaySpec.BOTTOM;
                default: return OverlaySpec.BOTTOM_RIGHT;
            }
        }

        OverlaySpec spec() {
            return OverlaySpec.at(anchor())
                .size(size, size)
                .inset(margin)
                .onTop(true)
                .closeOnBack(false)
                .enter(OverlaySpec.FADE)
                .exit(OverlaySpec.FADE);
        }

        @Override public boolean equals(Object o) {
            if (!(o instanceof Look)) return false;
            Look l = (Look) o;
            return corner.equals(l.corner) && icon.equals(l.icon) && size == l.size && margin == l.margin
                && iconColor == l.iconColor && buttonColor == l.buttonColor && opacity == l.opacity && outline == l.outline;
        }

        @Override public int hashCode() { return corner.hashCode() * 31 + icon.hashCode() + size; }
    }

    private PluginHost host;
    private Look look;
    private boolean always;
    private boolean hideDuringVoice = true;
    private boolean screensaverActive;
    private String voiceState = "idle";
    private Look shownLook;   // null while hidden
    private boolean running;

    @Override public synchronized void start(PluginHost host, Map<String, Object> settings) {
        this.host = host;
        running = true;
        apply(settings);
        if (host.isHeadless()) { status("No screen on this device, nothing to show", true); return; }

        subscribe("screensaver.state");
        subscribe("voice.state");
        host.executeCommand("isScreensaverActive", Collections.<String, Object>emptyMap(), (ok, data, error) -> {
            if (ok && data instanceof Boolean) onScreensaver((Boolean) data);
        });
        try {
            host.executeCommand("getVoiceState", Collections.<String, Object>emptyMap(), (ok, data, error) -> {
                if (ok && data instanceof Map) {
                    Object state = ((Map<?, ?>) data).get("state");
                    if (state instanceof String) onVoice((String) state);
                }
            });
        } catch (RuntimeException olderHost) {
            host.log("Voice state unavailable: " + olderHost.getMessage());
        }
        refresh();
    }

    @Override public synchronized void configure(Map<String, Object> settings) {
        apply(settings);
        refresh();
    }

    @Override public synchronized void execute(String command, Map<String, Object> arguments) {
        if ("tap".equals(command)) press();
    }

    @Override public synchronized void onEvent(String event, Map<String, Object> payload) {
        if ("ks.screensaver.state".equals(event)) {
            Object active = payload == null ? null : payload.get("active");
            if (active instanceof Boolean) onScreensaver((Boolean) active);
        } else if ("ks.voice.state".equals(event)) {
            Object state = payload == null ? null : payload.get("state");
            if (state instanceof String) onVoice((String) state);
        } else if ("overlay.closed".equals(event)) {
            shownLook = null;   // closed from outside; the next change shows it again
        }
    }

    @Override public synchronized void stop() {
        running = false;
        shownLook = null;   // KS removes a stopped session's overlays itself
        host = null;
    }

    // ---- state ----

    private void apply(Map<String, Object> settings) {
        look = new Look(settings);
        always = "Always".equals(text(settings, "showWhen", "Screensaver only"));
        hideDuringVoice = flag(settings, "hideDuringVoice", true);
    }

    synchronized void onScreensaver(boolean active) {
        screensaverActive = active;
        refresh();
    }

    synchronized void onVoice(String state) {
        voiceState = state;
        refresh();
    }

    boolean wanted() {
        if (always || screensaverActive) return !(hideDuringVoice && !"idle".equals(voiceState));
        return false;
    }

    private void refresh() {
        if (!running || host == null || host.isHeadless()) return;
        try {
            if (wanted()) {
                if (!look.equals(shownLook)) {
                    final Look l = look;
                    host.showOverlay(OVERLAY, l.spec(), new ButtonFactory(l));
                    shownLook = l;
                }
                status("Button showing", false);
            } else {
                if (shownLook != null) host.hideOverlay(OVERLAY);
                shownLook = null;
                status(always ? "Hidden while the assistant is busy" : "Waiting for the screensaver", false);
            }
        } catch (UnsupportedOperationException older) {
            status("This Kiosk Satellite version has no native overlays. Update the app.", true);
        } catch (IllegalStateException ended) {
            // Session ended or the per-second overlay limit was hit; the next event retries.
            shownLook = null;
        }
    }

    /** Fires the gesture trigger. Safe from the main thread; never throws into Android. */
    void press() {
        PluginHost h;
        synchronized (this) { h = host; }
        if (h == null) return;
        try {
            h.fireTrigger(TRIGGER);
        } catch (UnsupportedOperationException older) {
            status("This Kiosk Satellite version has no gesture triggers. Update the app.", true);
        } catch (RuntimeException ended) {
            // Session ended between the tap and the call.
        }
    }

    private void subscribe(String event) {
        try { host.subscribe(event); }
        catch (RuntimeException older) { host.log("Cannot follow " + event + ": " + older.getMessage()); }
    }

    private void status(String message, boolean error) {
        try { if (host != null) host.status(message, error); } catch (RuntimeException ignored) {}
    }

    // ---- the view ----

    final class ButtonFactory implements OverlayFactory {
        private final Look l;
        ButtonFactory(Look l) { this.l = l; }

        @Override public View create(Context context, KsTheme theme) {
            ImageView button = new ImageView(context);
            style(button, theme);
            button.setClickable(true);
            button.setContentDescription("Talk to the assistant");
            button.setOnClickListener(v -> {
                try {
                    v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80)
                        .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()).start();
                } catch (Throwable ignored) {}
                press();
            });
            return button;
        }

        @Override public void onThemeChanged(View view, KsTheme theme) {
            try { if (view instanceof ImageView) style((ImageView) view, theme); } catch (Throwable ignored) {}
        }

        private void style(ImageView button, KsTheme theme) {
            GradientDrawable circle = new GradientDrawable();
            circle.setShape(GradientDrawable.OVAL);
            int alpha = Math.round(l.opacity * 2.55f);
            circle.setColor(Color.argb(alpha, Color.red(l.buttonColor), Color.green(l.buttonColor), Color.blue(l.buttonColor)));
            if (l.outline) circle.setStroke(Math.max(1, theme.px(1.5f)), Color.argb(110, Color.red(l.iconColor), Color.green(l.iconColor), Color.blue(l.iconColor)));
            button.setBackground(circle);

            Drawable icon = null;
            try {
                icon = theme.icon(l.icon, "onSurface");
                if (icon == null) icon = theme.icon(DEFAULT_ICON, "onSurface");
            } catch (LinkageError olderKs) {
                icon = null;
            }
            if (icon != null) {
                icon = icon.mutate();
                icon.setTint(l.iconColor);
            }
            button.setImageDrawable(icon);
            button.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int pad = theme.px(l.size * 0.24f);
            button.setPadding(pad, pad, pad, pad);
        }
    }

    // ---- settings helpers ----

    static String text(Map<String, Object> s, String key, String fallback) {
        Object v = s == null ? null : s.get(key);
        return v instanceof String ? (String) v : fallback;
    }

    static int number(Map<String, Object> s, String key, int fallback) {
        Object v = s == null ? null : s.get(key);
        return v instanceof Number ? Math.round(((Number) v).floatValue()) : fallback;
    }

    static boolean flag(Map<String, Object> s, String key, boolean fallback) {
        Object v = s == null ? null : s.get(key);
        return v instanceof Boolean ? (Boolean) v : fallback;
    }

    static int color(Map<String, Object> s, String key, int fallback) {
        try { return Color.parseColor(text(s, key, "")); } catch (RuntimeException bad) { return fallback; }
    }
}
