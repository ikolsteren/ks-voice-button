// SPDX-License-Identifier: Apache-2.0
package ca.kolsteren.voicebutton;

import java.util.*;
import me.jxl.kiosk.plugins.OverlayFactory;
import me.jxl.kiosk.plugins.OverlaySpec;
import me.jxl.kiosk.plugins.PluginHost;

/** Checks when the button is asked for and what a tap fires. Drawing the view needs a device. */
public final class VoiceButtonTest {
    static final class Host implements PluginHost {
        final List<String> calls = new ArrayList<>();
        final Set<String> subscribed = new HashSet<>();
        final List<String> fired = new ArrayList<>();
        OverlaySpec spec;
        boolean screensaver;
        public void showOverlay(String key, OverlaySpec spec, OverlayFactory factory) {
            assert factory != null && VoiceButtonPlugin.OVERLAY.equals(key);
            this.spec = spec; calls.add("show");
        }
        public void hideOverlay(String key) { spec = null; calls.add("hide"); }
        public void subscribe(String event) { subscribed.add(event); }
        public void executeCommand(String command, Map<String, Object> args, CommandCallback cb) {
            if ("isScreensaverActive".equals(command)) cb.onResult(true, screensaver, null);
            else if ("getVoiceState".equals(command)) cb.onResult(true, Collections.<String, Object>singletonMap("state", "idle"), null);
            else cb.onResult(false, null, "unknown");
        }
        public void fireTrigger(String id) { fired.add(id); }
        public void status(String message, boolean error) {}
        public void showWindow(String t, String m, String b) {}
        public void hideWindow() {}
        public void log(String message) {}
    }

    static Map<String, Object> defaults() {
        Map<String, Object> s = new HashMap<>();
        s.put("showWhen", "Screensaver only"); s.put("hideDuringVoice", true); s.put("corner", "Bottom right");
        s.put("size", 72.0); s.put("margin", 20.0); s.put("icon", "mdi:microphone");
        s.put("iconColor", "#FFFFFF"); s.put("buttonColor", "#000000"); s.put("opacity", 45.0); s.put("outline", true);
        return s;
    }

    static Map<String, Object> event(String key, Object value) { return Collections.singletonMap(key, value); }

    public static void main(String[] args) throws Exception {
        Host host = new Host();
        VoiceButtonPlugin plugin = new VoiceButtonPlugin();

        // Dashboard showing: nothing drawn, events followed.
        plugin.start(host, defaults());
        assert host.calls.isEmpty() : host.calls;
        assert host.subscribed.contains("screensaver.state") && host.subscribed.contains("voice.state");

        // Screensaver starts: the button appears on top of it, in the chosen corner.
        plugin.onEvent("ks.screensaver.state", event("active", true));
        assert host.calls.equals(Arrays.asList("show")) : host.calls;
        assert host.spec.onTop() : "must sit above the screensaver";
        assert OverlaySpec.BOTTOM_RIGHT.equals(host.spec.anchor());

        // Repeated events do not rebuild the view.
        plugin.onEvent("ks.screensaver.state", event("active", true));
        assert host.calls.size() == 1 : host.calls;

        // A tap fires the trigger.
        plugin.press();
        assert host.fired.equals(Arrays.asList("micTap")) : host.fired;

        // The assistant takes over: hidden, then back once idle.
        plugin.onEvent("ks.voice.state", event("state", "listening"));
        assert host.spec == null && host.calls.get(host.calls.size() - 1).equals("hide");
        plugin.onEvent("ks.voice.state", event("state", "idle"));
        assert host.spec != null;

        // Screensaver ends: hidden again.
        plugin.onEvent("ks.screensaver.state", event("active", false));
        assert host.spec == null;

        // Always mode shows it over the dashboard; moving the corner rebuilds it there.
        Map<String, Object> always = defaults();
        always.put("showWhen", "Always"); always.put("corner", "Top left");
        plugin.configure(always);
        assert host.spec != null && OverlaySpec.TOP_LEFT.equals(host.spec.anchor());

        // Top centre with a label: a pill that sizes to its text, same height.
        Map<String, Object> pill = new HashMap<>(always);
        pill.put("corner", "Top centre"); pill.put("style", "Icon and label"); pill.put("label", "Ask Nabu");
        plugin.configure(pill);
        assert OverlaySpec.TOP.equals(host.spec.anchor());
        assert host.spec.width() == OverlaySpec.WRAP && host.spec.height() == 72 : host.spec.width() + "x" + host.spec.height();

        // An empty label falls back to the round icon.
        pill.put("label", "  ");
        plugin.configure(pill);
        assert host.spec.width() == 72;

        // The drawer/HA command does the same as a tap.
        plugin.execute("tap", Collections.<String, Object>emptyMap());
        assert host.fired.size() == 2;

        plugin.stop();
        plugin.press();
        assert host.fired.size() == 2 : "no fires after stop";
        System.out.println("VoiceButtonTest passed");
    }
}
